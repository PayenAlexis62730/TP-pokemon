<template>
  <div>
    <!-- Composant ListeTypesPokemon affichant la liste des types de Pokémon avec leurs occurrences -->
    <ListeTypesPokemon :pokemonList="pokemonList" />

    <!-- Bouton de choix de génération -->
    <div>
      <label for="generation">Sélectionnez la génération :</label>
      <select v-model="selectedGeneration" @change="fetchPokemonData">
        <option v-for="generation in generations" :key="generation" :value="generation">
          Génération {{ generation }}
        </option>
      </select>
    </div>

    <!-- Liste de cartes Pokémon -->
    <div class="pokedex">
      <router-link :to="{ name: 'pokemon-details', params: { idPokemon: pokemon.id } }" v-for="pokemon in pokemonList" :key="pokemon.name">
        <Pokemon :pokemon="pokemon" />
      </router-link>
    </div>

    <!-- Route pour afficher les détails du Pokémon -->
    <router-view></router-view>
  </div>
</template>

<script>
import axios from 'axios';
import Pokemon from './Pokemon.vue';
import ListeTypesPokemon from './ListeTypesPokemon.vue';

export default {
  components: {
    Pokemon,
    ListeTypesPokemon,
  },
  data() {
    return {
      pokemonList: [],
      selectedGeneration: 1,
      generations: [1, 2, 3, 4, 5, 6, 7, 8],
    };
  },
  mounted() {
    this.fetchPokemonData();
  },
  watch: {
    selectedGeneration() {
      this.fetchPokemonData();
    },
  },
  methods: {
    async fetchPokemonData() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/generation/${this.selectedGeneration}`);
        this.pokemonList = response.data;
      } catch (error) {
        console.error('Erreur lors de la récupération des données Pokémon :', error);
      }
    },
  },
};
</script>

<style scoped>
.pokedex {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

</style>
