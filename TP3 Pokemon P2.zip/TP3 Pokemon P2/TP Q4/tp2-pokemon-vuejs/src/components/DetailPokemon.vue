<template>
  <div>
    <!-- Affichez les détails du Pokémon ici -->
    <h2>{{ pokemonDetails.name }}</h2>
    <p>Numéro: {{ pokemonDetails.id }}</p>
    <p>Type: {{ pokemonDetails.type }}</p>

    <router-link :to="{ name: 'pokemon-list' }">Retour à la liste des Pokémon</router-link>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      pokemonDetails: {},
    };
  },
  async mounted() {
    // Récupérer l'identifiant du Pokémon depuis les paramètres de l'URL
    const idPokemon = this.$route.params.idPokemon;

    // Appeler l'API pour obtenir les détails du Pokémon en utilisant l'identifiant
    try {
      const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${idPokemon}`);
      this.pokemonDetails = response.data;
    } catch (error) {
      console.error('Erreur lors de la récupération des détails du Pokémon :', error);
    }
  },
};
</script>

<style scoped>
/* Styles spécifiques au composant DetailsPokemon */
.details-pokemon {
  text-align: center;
  margin-top: 20px;
}
</style>
