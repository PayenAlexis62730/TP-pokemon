<template>
    <footer class="footer">
      <p>{{ NomPrenom }} - TP{{ NumTP }}</p>
    </footer>
  </template>
  
  <script>
  export default {
    data() {
      return {
        NomPrenom: 'Payen Alexis', 
        NumTP: '.D', 
      };
    },
  };
  </script>
  
  <style scoped>
.footer {
  background-color: #f0f0f0;
  padding: 1px; 
  text-align: center;
  position: fixed;
  bottom: 0;
  width: 100%;
  left: 0;
}
</style>