<template>
    <div class="liste-types-pokemon">
      <h2>Liste des Types de Pokémon</h2>
      <ul>
        <li v-for="type in OccurenceType" :key="type.name">
          {{ type.name }} : {{ type.occurrences }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      // Propriété pour recevoir la liste des Pokémon
      pokemonList: {
        type: Array,
        required: true,
      },
    },
    computed: {
      // Calculer les types avec leurs occurrences
      OccurenceType() {
        const CompterType = {};
        // Parcourir la liste des Pokémon
        this.pokemonList.forEach((pokemon) => {
          // Utiliser uniquement le premier type du Pokémon 
          const PremierType = pokemon.apiTypes[0].name;
          // Incrémenter le compteur pour le type
          CompterType[PremierType] = (CompterType[PremierType] || 0) + 1;
        });
  
        // Convertir la carte des types en tableau d'objets
        return Object.entries(CompterType).map(([name, occurrences]) => ({ name, occurrences }));
      },
    },
  };
  </script>
  
  <style scoped>
  /* Styles spécifiques au composant ListeTypesPokemon */
  .liste-types-pokemon {
    margin-bottom: 20px;
  }
  
  /* Styles pour la liste des types */
  ul {
    list-style-type: none;
    padding: 0;
  }
  
  li {
    margin-bottom: 5px;
  }
  </style>
  