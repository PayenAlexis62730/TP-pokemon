<template>
  <div id="app">
    <Pokedex :pokemon-list="pokemonList" />
    <Footer />
  </div>
</template>

<script>
import Pokedex from './components/Pokedex.vue';
import Footer from './components/footer.vue';

export default {
  components: {
    Pokedex,
    Footer,
  },
  data() {
    return {
      pokemonList: [
        {
          "name": "Bulbizarre",
          "image": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png",
          "apiTypes": [
            {
              "name": "Plante",
              "image": "https://static.wikia.nocookie.net/pokemongo/images/c/c5/Grass.png",
              "color": "#8BBE8A",
            }
          ],
          "apiGeneration": 1
        },
      ],
    };
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
