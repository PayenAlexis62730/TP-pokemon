<template>
    <!-- Conteneur principal des détails du Pokémon -->
    <div class="details-pokemon">
      <!-- Titre avec le nom du Pokémon -->
      <h2>{{ pokemonDetails.name }}</h2>
      
      <!-- Image du Pokémon -->
      <img :src="pokemonDetails.image" :alt="pokemonDetails.name" />
      
      <!-- Liste des types du Pokémon -->
      <p>Types :</p>
      <ul>
        <li v-for="type in pokemonDetails.apiTypes" :key="type.name">
          {{ type.name }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        // Objet pour stocker les détails du Pokémon
        pokemonDetails: {},
      };
    },
    methods: {
      // Méthode pour récupérer les détails du Pokémon depuis l'API
      async fetchPokemonDetails() {
        try {
          // Appel à l'API pour obtenir les détails du Pokémon en fonction de son identifiant
          const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${this.$route.params.idPokemon}`);
          
          // Mise à jour des détails du Pokémon dans le composant
          this.pokemonDetails = response.data;
        } catch (error) {
          // Gestion des erreurs en cas d'échec de la requête
          console.error('Error fetching Pokemon details:', error);
        }
      },
    },
    mounted() {
      // Appel pour récupérer et afficher les détails du Pokémon lors du chargement de la page
      this.fetchPokemonDetails();
    },
  };
  </script>
  
  <style scoped>
  /* Styles spécifiques au composant DetailsPokemon */
  .details-pokemon {
    text-align: center;
    margin-top: 20px;
  }
  </style>
  