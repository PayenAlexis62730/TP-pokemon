<!-- Pokedex.vue -->

<template>
  <div class="pokedex">
    <!-- Liste des types de Pokémon -->
    <ListeTypesPokemon :pokemonList="pokemonList" />

    <!-- Contrôles pour définir le nombre de Pokémon à afficher -->
    <div class="controls">
      <label for="numberOfPokemons">Nombre de Pokémon :</label>
      <input type="number" id="numberOfPokemons" v-model="numberOfPokemons" />
      <button @click="fetchPokemonData">Afficher</button>
    </div>

    <!-- Liste des Pokémon affichés -->
    <div class="pokemon-list">
      <!-- Utilisation du composant Pokemon pour chaque Pokémon dans la liste -->
      <router-link :to="{ name: 'DetailsPokemon', params: { idPokemon: pokemon.name } }" v-for="pokemon in pokemonList" :key="pokemon.name">
        <Pokemon :pokemon="pokemon" />
      </router-link>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Pokemon from './Pokemon.vue';
import ListeTypesPokemon from './ListeTypesPokemon.vue';

export default {
  components: {
    Pokemon,
    ListeTypesPokemon,
  },
  data() {
    return {
      // Nombre initial de Pokémon à afficher
      numberOfPokemons: 20,
      // Liste des Pokémon récupérés de l'API
      pokemonList: [],
    };
  },
  methods: {
    // Méthode pour récupérer les données des Pokémon depuis l'API
    async fetchPokemonData() {
      try {
        // Appel à l'API avec le nombre spécifié de Pokémon
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/limit/${this.numberOfPokemons}`);
        // Mise à jour de la liste des Pokémon
        this.pokemonList = response.data;
      } catch (error) {
        // Gestion des erreurs en cas d'échec de la requête
        console.error('Error fetching Pokemon data:', error);
      }
    },
  },
  mounted() {
    // Appel initial pour afficher les Pokémon lors du chargement de la page
    this.fetchPokemonData();
  },
};
</script>

<style scoped>
/* Styles spécifiques au composant Pokedex */
.pokedex {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
}

/* Styles pour la section des contrôles (input et bouton) */
.controls {
  margin-bottom: 20px;
}

/* Styles pour la liste des Pokémon */
.pokemon-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
</style>
