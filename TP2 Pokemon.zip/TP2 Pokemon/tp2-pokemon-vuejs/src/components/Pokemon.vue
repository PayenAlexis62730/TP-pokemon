<template>
  <div :style="{ backgroundColor: primaryTypeColor }" class="pokemon-card">
    <img :src="pokemon.image" :alt="pokemon.name" class="pokemon-image" />
    <div class="pokemon-info">
      <h2>{{ pokemon.name }}</h2>
      <div v-for="type in pokemon.apiTypes" :key="type.name" class="type">
        <img :src="type.image" :alt="type.name" class="type-image" />
        <span>{{ type.name }}</span>
      </div>
      <p>Generation: {{ pokemon.apiGeneration }}</p>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    pokemon: {
      type: Object,
      required: true,
    },
  },
  computed: {
    primaryTypeColor() {
      return this.pokemon.apiTypes.length > 0 ? this.pokemon.apiTypes[0].color : 'white';
    },
  },
};
</script>

<style scoped>
.pokemon-card {
  width: 300px;
  padding: 20px;
  border-radius: 10px;
  margin: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}

.pokemon-image {
  width: 150px;
  height: 150px;
  object-fit: cover;
  border-radius: 50%;
}

.pokemon-info {
  margin-top: 10px;
  text-align: center;
}

.type {
  display: flex;
  align-items: center;
  margin-top: 5px;
}

.type-image {
  width: 20px;
  height: 20px;
  margin-right: 5px;
}

</style>
