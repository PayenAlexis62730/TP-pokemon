<template>
  <div class="pokedex">
    <Pokemon v-for="pokemon in pokemonList" :key="pokemon.name" :pokemon="pokemon" />
  </div>
</template>

<script>
import axios from 'axios';
import Pokemon from './Pokemon.vue';

export default {
  components: {
    Pokemon,
  },
  data() {
    return {
      pokemonList: [],
    };
  },
  mounted() {
    this.fetchPokemonData();
  },
  methods: {
    async fetchPokemonData() {
      try {
        const response = await axios.get('https://pokebuildapi.fr/api/v1/pokemon/limit/20');
        this.pokemonList = response.data;
      } catch (error) {
        console.error('Error fetching Pokemon data:', error);
      }
    },
  },
};
</script>

<style scoped>
.pokedex {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
</style>
